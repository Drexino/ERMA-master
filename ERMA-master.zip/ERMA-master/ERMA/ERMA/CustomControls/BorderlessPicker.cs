﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace ERMA.CustomControls
{
    public class BorderlessPicker: Picker
    {
    }
}
