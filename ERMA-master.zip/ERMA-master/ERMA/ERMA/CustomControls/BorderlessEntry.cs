﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.Internals;

namespace ERMA.CustomControls
{
    [Preserve(AllMembers = true)]
    public class BorderlessEntry : Entry
    {
    }
}
