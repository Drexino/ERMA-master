using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: ExportFont("OpenSans-Regular.ttf", Alias = "OPRegular")]
[assembly: ExportFont("OpenSans-SemiBold.ttf", Alias = "OPSemiBold")]
[assembly: ExportFont("OpenSans-Light.ttf", Alias = "OPLight")]