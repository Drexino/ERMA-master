﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERMA.Helper
{
    public class MessageCenterTypes
    {
        public const string M_C_SHOW_SIDE_MENU = "show.menu.message";
    }
}
